/* $Id: brcups_commands.h,v 1.11 2005/08/22 02:20:49 cvs Exp $ */
//* Brother CUPS wrapper tool
//* Copyright (C) 2005 Brother. Industries, Ltd.//*
//*                                    Ver1.00
//*
//* This program is free software; you can redistribute it and/or modify it
//* under the terms of the GNU General Public License as published by the Free
//* Software Foundation; either version 2 of the License, or (at your option)
//* any later version.
//*
//* This program is distributed in the hope that it will be useful, but WITHOUT
//* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
//* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
//* more details.
//*
//* You should have received a copy of the GNU General Public License along with
//* this program; if not, write to the Free Software Foundation, Inc., 59 Temple
//* Place, Suite 330, Boston, MA  02111-1307  USA
//*

#ifndef _BRCUPS_COMMANDS_H_
#define _BRCUPS_COMMANDS_H_

#ifndef _BROTHER_LASER_  				
#define _BROTHER_LASER_
#endif					


char brprintconf[30]="brprintconf";
/*
//   +++++++++++++++++++++++++++
//       set default
//   +++++++++++++++++++++++++++

char *default_setting[] = {
		// Collate
		"brprintconf -P BROTHERPRINTER_XXX  -collate OFF"   ,
		// copies
		"brprintconf -P BROTHERPRINTER_XXX  -copy 1",
		// Chain
		"brprintconf -P BROTHERPRINTER_XXX  -md Plain",
		// Bringhtness
		"brprintconf -P BROTHERPRINTER_XXX  -brit 0"   ,
		// Contrast
		"brprintconf -P BROTHERPRINTER_XXX  -cont 0"   ,
		// Halftone
		"brprintconf -P BROTHERPRINTER_XXX  -half ErrorDiffusion"   ,
		// Auto cut
		"brprintconf -P BROTHERPRINTER_XXX  -hcut ON"   ,
		// Auto cut
		"brprintconf -P BROTHERPRINTER_XXX  -cut OFF"   ,
		// Mirror
		"brprintconf -P BROTHERPRINTER_XXX  -mirro OFF"   ,
		// Resolution
		"brprintconf -P BROTHERPRINTER_XXX  -reso Normal"   ,
		// Margin(Feed)
		"brprintconf -P BROTHERPRINTER_XXX  -margin 1",
		// Media
		"brprintconf -P BROTHERPRINTER_XXX  -media brS12mm",
	     
	     NULL
};


*/

		
typedef struct {
    char *option;                                 
    char *value;
} CMDLINELIST;
//   +++++++++++++++++++++++++++

//       command line   (Brother command)
//   +++++++++++++++++++++++++++

CMDLINELIST commandlinelist[] = {
	// Collate
	{  "BRCollate=OFF"			,	"-collate OFF"      },
	{  "BRCollate=ON"			,	"-collate OFF"      },    
  // Media                                               
	{  "BRMediaType=Plain"			,	"-md Plain"      },
	{  "BRMediaType=Thin"			,	"-md Thin"      },
	{  "BRMediaType=Thick"	,	"-md Thick"      },
	{  "BRMediaType=Thicker"	,	"-md Thicker"      },
  {  "BRMediaType=BOND"			,	"-md BOND"      },
  {  "BRMediaType=Recycled"	,	"-md Recycled"      },
  {  "BRMediaType=Env"	,	"-md Env"      },
  {  "BRMediaType=EnvThin"	,	"-md EnvThin"      },
  {  "BRMediaType=EnvThick"	,	"-md EnvThick"      },
  {  "BRMediaType=PostCard"	,	"-md Postcard"      },
  {  "BRMediaType=Label"	,	"-md Label"      },
#ifdef _BROTHER_LASER_
  {  "BRMediaType=Glossy"	,	"-md Glossy"      },
#endif 

 // RResolution
	{  "BRResolution=600dpi"	,	"-reso Normal"      },
	{  "BRResolution=600x2400dpi"	,	"-reso Fine"      },

	// Mirror
/*	{  "MirrorPrint=OFF"	,	"-mirro OFF"	},
	{  "MirrorPrint=ON"	,	"-mirro ON"	},
	{  "NoMirrorPrint"	,	"-mirro OFF"	},
	{  "MirrorPrint"	,	"-mirro ON"	},      */

	//InputSlot
	{  "BRInputSlot=AutoSelect",	"-inslot AutoSelect"	},
	{  "BRInputSlot=Tray1"	,	"-inslot Tray1"	},
	{  "BRInputSlot=Manual"	,	"-inslot Manual"	},
#ifdef _BROTHER_LASER_ 
	{  "BRInputSlot=Tray2"	,	"-inslot Tray2"	},
	{  "BRInputSlot=MPTray"	,	"-inslot MPTray"	},
#endif // end _BROTHER_LASER_

	// BRMonoColor
  {  "BRMonoColor=Auto"	,	"-corm Auto"	},
	{  "BRMonoColor=FullColor"	,	"-corm FullColor"	},
	{  "BRMonoColor=Mono"	,	"-corm Mono"	},

// Paper
  { "PageSize=A4",				"-pt A4" },
  { "PageSize=Letter",				"-pt Letter" },
  { "PageSize=Legal",				"-pt Legal" },
  { "PageSize=Executive",				"-pt Executive" }, 
  { "PageSize=A5",				"-pt A5" },
  { "PageSize=A5Rotated",				"-pt PRA5Rotated" },
  { "PageSize=A6",				"-pt A6" },
  { "PageSize=B5",				"-pt ISOB5" },
  { "PageSize=B6",				"-pt ISOB6" },
  { "PageSize=JISB5",				"-pt JISB5" },
  { "PageSize=JISB6",				"-pt JISB6" },

  { "PageSize=EnvDL",				"-pt EnvDL" },
  { "PageSize=EnvC5",				"-pt EnvC5" },
  { "PageSize=Env10",				"-pt Env10" },
  { "PageSize=EnvMonarch",				"-pt EnvMonarch" },
	{ "PageSize=Br3x5",			"-pt Br3x5" },
#ifndef _BROTHER_LASER_ 
	{ "PageSize=BrA4Long",		"-pt BrA4Long" },
#endif // end _BROTHER_LASER_
	{ "PageSize=FanFoldGermanLegal",				"-pt FanFoldGermanLegal" },
	{ "PageSize=EnvPRC5Rotated",				"-pt EnvPRC5Rotated" },
	{ "PageSize=Postcard",				"-pt Postcard" },
	{ "PageSize=EnvYou4",			"-pt EnvYou4" },
	{ "PageSize=EnvChou3",		"-pt EnvChou3" },

	
	// for Command Line
  { "media=A4",				"-pt A4" },
  { "media=Letter",				"-pt Letter" },
  { "media=Legal",				"-pt Legal" },
  { "media=Executive",				"-pt Executive" },
  { "media=A5",				"-pt A5" },
  { "media=A5Rotated",				"-pt PRA5Rotated" },
  { "media=A6",				"-pt A6" },
  { "media=B5",				"-pt ISOB5" },
  { "media=B6",				"-pt ISOB6" },
  { "media=JISB5",				"-pt JISB5" },

  { "media=JISB6",				"-pt JISB6" },
  { "media=EnvDL",				"-pt EnvDL" },
  { "media=EnvC5",				"-pt EnvC5" },
  { "media=Env10",				"-pt Env10" },
  { "media=EnvMonarch",				"-pt EnvMonarch" },
	{ "media=Br3x5",			"-pt Br3x5" },
#ifndef _BROTHER_LASER_ 
	{ "media=BrA4Long",		"-pt BrA4Long" },
#endif // end _BROTHER_LASER_
	{ "media=FanFoldGermanLegal",				"-pt FanFoldGermanLegal" },
	{ "media=EnvPRC5Rotated",				"-pt EnvPRC5Rotated" },

	{ "media=Postcard",				"-pt Postcard" },
	{ "media=EnvYou4",			"-pt EnvYou4" },
	{ "media=EnvChou3",		"-pt EnvChou3" },


// Gray
	{ "BRGray=OFF", "-gray OFF" },               
	{ "BRGray=ON", "-gray ON" },


	// ColorMatch
	{ "BRColorMatching=Normal", "-cm Normal" },
	{ "BRColorMatching=Vivid", "-cm Vivid" },
	{ "BRColorMatching=None", "-cm None" },

	// ToneSave
	{ "BRTonerSaveMode=OFF", "-ts OFF" },
	{ "BRTonerSaveMode=ON", "-ts ON" },

	// BRImproveOutput
#ifdef _BROTHER_LASER_ 
	{ "BRImproveOutput=OFF", "-improve OFF" },
	{ "BRImproveOutput=BRLessPaperCurl", "-improve BRLessPaperCurl" },
	{ "BRImproveOutput=BRFixIntensity", "-improve BRFixIntensity" },
#else      // _BROTHER_LASER_
	{ "BRImproveOutput=OFF", "-output OFF" },
	{ "BRImproveOutput=BRLessPaperCurl", "-output BRLessPaperCurl" },       adf
	{ "BRImproveOutput=BRFixIntensity", "-output BRFixIntensity" },
#endif       // end _BROTHER_LASER_


	// BREnhanceBlkPrt

#ifdef _BROTHER_LASER_ 
	{ "BREnhanceBlkPrt=OFF", "-bp OFF" },
	{ "BREnhanceBlkPrt=ON", "-bp ON" },
#else      // _BROTHER_LASER_
	{ "BREnhanceBlkPrt=OFF", "-ce OFF" },
	{ "BREnhanceBlkPrt=ON", "-ce ON" },
#endif       // end _BROTHER_LASER_


 	//BRReversePrint
#ifdef _BROTHER_LASER_ 
  	{"BRReverse=ON","-rev ON"},
  	{"BRReverse=OFF","-rev OFF"},
#else      // _BROTHER_LASER_
  	{"BRReverse=ON","-reve ON"},
  	{"BRReverse=OFF","-reve OFF"},
#endif       // end _BROTHER_LASER_


#ifdef _BROTHER_LASER_ 
    // Duplex
	  {  "BRDuplex=None"				,	"-duplex None"  },
    {  "BRDuplex=DuplexTumble"		,	"-duplex DuplexTumble"  },
    {  "BRDuplex=DuplexNoTumble"	,	"-duplex DuplexNoTumble"  },


    // Skip Blank Page
    {  "BRSkipBlank=OFF"  , "-sb OFF" },
    {  "BRSkipBlank=ON"   , "-sb ON"  },
    
#else      // _BROTHER_LASER_

    // Duplex

/*    {  "Duplex=None"				,	"-duplex None"  },
    {  "Duplex=DuplexTumble"		,	"-duplex DuplexTumble"  },
    {  "Duplex=DuplexNoTumble"	,	"-duplex DuplexNoTumble"  },     */
    // ManualDuplex
//    {  "ManualDuplex=off"				,	"-mandup off"  },
//    {  "ManualDuplex=even"		,	"-mandup even"  },
//    {  "ManualDuplex=odd"	,	"-mandup odd"  },

#endif       // end _BROTHER_LASER_
	{ NULL   ,   NULL    },
};



//   +++++++++++++++++++++++++++
//       command line   (Standard command)
//   +++++++++++++++++++++++++++
CMDLINELIST standard_commandlinelist[] = {
	// for Fedora OpenOffice
/*	{ "PageSize=A4",				"-pt A4" },
       { "PageSize=BrA4_B",			"-pt BrA4_B" },
	{ "PageSize=Letter",			"-pt Letter" },
	{ "PageSize=BrLetter_B",		"-pt BrLetter_B" },
	{ "PageSize=Legal",			"-pt Legal" },
	{ "PageSize=Executive",		"-pt Executive" },
	{ "PageSize=B5",				"-pt B5" },
	{ "PageSize=A5",				"-pt A5" },

	{ "PageSize=A6",				"-pt A6" },
	{ "PageSize=BrA6_B",			"-pt BrA6_B" },
	{ "PageSize=PostC4x6",		"-pt PostC4x6" },
	{ "PageSize=BrPostC4x6_B",	"-pt BrPostC4x6_B" },
	{ "PageSize=IndexC5x8",		"-pt IndexC5x8" },
	{ "PageSize=BrIndexC5x8_B",	"-pt BrIndexC5x8_B" },
	{ "PageSize=PhotoL",		"-pt PhotoL" },
       { "PageSize=BrPhotoL_B",		"-pt BrPhotoL_B" },
       { "PageSize=Photo2L",		"-pt Photo2L" },
       { "PageSize=BrPhoto2L_B",		"-pt BrPhoto2L_B" },
       { "PageSize=Postcard",		"-pt Postcard" },
       { "PageSize=BrHagaki_B",		"-pt BrHagaki_B" },

       { "PageSize=DoublePostcardRotated",	"-pt DoublePostcardRotated" },
       { "PageSize=EnvC5",				"-pt EnvC5" },
       { "PageSize=EnvDL",				"-pt EnvDL" },
       { "PageSize=Env10",				"-pt Env10" },
       { "PageSize=EnvMonarch",			"-pt EnvMonarch" },
       { "PageSize=EnvYou4",				"-pt EnvYou4" },

*/	{ NULL   ,   NULL    },
};

//   +++++++++++++++++++++++++++
//       command line numerical value
//   +++++++++++++++++++++++++++
CMDLINELIST commandlinelist2[] = {

#ifndef	_BROTHER_LASER_	
	{	"Copies="   	,   "-copies "      },
#endif	// _BROTHER_LASER_

	{	"BRBrightness="	,	"-brit "	},
	{	"BRContrast="		,	"-cont "		},

	{   "BRRed="		,	"-red "		},
	{   "BRGreen="		,	"-green "		},
	{   "BRBlue="		,	"-blue "		},
	{   "BRSaturation="		,	"-satu "		},   
	   { NULL   ,   NULL    },
};
/*      PPD Default   */
//   +++++++++++++++++++++++++++
//       PPD setting list
//   +++++++++++++++++++++++++++



typedef struct {
    char *value;
    char *brcommand;
} PPDCOMMANDLIST;


typedef   struct   {
   char             *label;
   PPDCOMMANDLIST   ppdcommandlist[];
}  PPDCOMMAND;

//       ***** DefaultBRResolution *****
PPDCOMMAND  DefaultBRResolution={
  "DefaultBRResolution",
	{
		{ "600dpi"  , "-reso Normal"  },
		{ "600x2400dpi"  , "-reso Fine"  },
		{ NULL , NULL  }
	}
};

//       ***** DefaultPageSize *****
PPDCOMMAND  DefaultPageSize={                                  
    "DefaultPageSize",
  {
	{ "A4",				"-pt A4" },
  { "Letter",				"-pt Letter" },
  { "Legal",				"-pt Legal" },
  { "Executive",				"-pt Executive" },
  { "A5",				"-pt A5" },
  { "A5Rotated",				"-pt PRA5Rotated" },
  { "A6",				"-pt A6" },

  { "B5",				"-pt ISOB5" },
  { "B6",				"-pt ISOB6" },
  { "JISB5",				"-pt JISB5" },
  { "JISB6",				"-pt JISB6" },

  { "EnvDL",				"-pt EnvDL" },
  { "EnvC5",				"-pt EnvC5" },
  { "Env10",				"-pt Env10" },
  { "EnvMonarch",				"-pt EnvMonarch" },
	{ "Br3x5",			"-pt Br3x5" },
	{ "FanFoldGermanLegal",				"-pt FanFoldGermanLegal" },
	{ "EnvPRC5Rotated",				"-pt EnvPRC5Rotated" },
	{ "Postcard",				"-pt Postcard" },
	{ "EnvYou4",			"-pt EnvYou4" },
	{ "EnvChou3",		"-pt EnvChou3" },   
       { NULL , NULL  }
     }
};


//       ***** DefaultBRMonoColor*****
PPDCOMMAND  DefaultBRMonoColor={
    "DefaultBRMonoColor",
    {
		{  "Auto"	,	"-corm Auto"	},
		{  "FullColor"	,	"-corm FullColor"	},
		{  "Mono"	,	"-corm Mono"	},
 	    	{ NULL , NULL  }
     }
};

//       ***** DefaultBRGray*****

PPDCOMMAND  DefaultBRGray={
	"DefaultBRGray",
	{
		{  "OFF"	,	"-gray OFF"	},
		{  "ON"	,	"-gray ON"	},
		{ NULL , NULL  }
	}
};


//       ***** DefaultMediaType*****
PPDCOMMAND  DefaultBRMediaType={
    "DefaultBRMediaType",
    {
	{  "Plain"			,	"-md Plain"      },
	{  "Thin"			,	"-md Thin"      },
  {  "Thick"	,	"-md Thick"      },
  {  "Thicker"	,	"-md Thicker"      },                    
  {  "BOND"			,	"-md BOND"      },
  {  "Recycled"	,	"-md Recycled"      },
  {  "Env"	,	"-md Env"      },
  {  "EnvThin"	,	"-md EnvThin"      },
  {  "EnvThick"	,	"-md EnvThick"      },
  {  "PostCard"	,	"-md Postcard"      },
  {  "Label"	,	"-md Label"      },
  {  "Glossy"	,	"-md Glossy"      },
 	{ NULL , NULL  }
     }
};


//       ***** DefaultBRColorPaperThick *****
/*PPDCOMMAND  DefaultBRColorPaperThick={
    "DefaultBRColorPaperThick",
    {
	{ "Regular", "-thick Regular" },
	{ "Thick", "-thick Thick" },
 	{ NULL , NULL  }
     }
};   

//    ******DefaultBRBiDir**********
PPDCOMMAND  DefaultBRBiDir={
	"DefaultBRBiDir",
	{
		{  "OFF"	,	"-bidir OFF"	},
		{  "ON"	,	"-bidir ON"	},

		{ NULL , NULL  }
	}
};   */

//    ******DefaultBrMirror**********
/* PPDCOMMAND  DefaultBrMirrorPrint={
	"DefaultMirrorPrint",
	{
		{  "OFF"	,	"-mirro OFF"	},
		{  "ON"	,	"-mirro ON"	},
		{ NULL , NULL  }
	}
};  */

//    ******DefaultBRDocument**********
/* PPDCOMMAND  DefaultBRDocument={


	"DefaultBRDocument",
	{
		{ "Photo", "-doc Photo" },
		{ "Graphics", "-doc Graphics" },
		{ "custom", "-doc Custom" },
		{ NULL , NULL  }
	}
};    */

//    ******DefaultBRColorMatching**********
PPDCOMMAND  DefaultBRColorMatching={
	"DefaultBRColorMatching",
	{
		{ "Normal", "-cm Normal" }, 
		{ "Vivid", "-cm Vivid" },
		{ "None", "-cm None" },
		{ NULL , NULL  }
	}
};

//    ******DefaultBRHalfTonePattern**********
/* PPDCOMMAND  DefaultBRHalfTonePattern={
	"DefaultBRHalfTonePattern",
	{

		{ "Diffusion", "-ht Diffusion" },
		{ "Dither", "-ht Dither" },
		{ NULL , NULL  }
	}
};     */

//    ******DefaultBRTonerSaveMode**********
PPDCOMMAND  DefaultBRTonerSaveMode={
	"DefaultBRTonerSaveMode",
	{

		{ "OFF", "-ts OFF" },
		{ "ON", "-ts ON" },
		{ NULL , NULL  }
	}
};

//    ******DefaultBRImproveOutput**********
PPDCOMMAND  DefaultBRImproveOutput={
	"DefaultBRImproveOutput",
	{
    { "OFF", "-improve OFF" },
		{ "BRLessPaperCurl", "-improve BRLessPaperCurl" },
		{ "BRFixIntensity", "-improve BRFixIntensity" },
		{ NULL , NULL  }
	}
};  

//    ******DefaultBRColorEnhancement**********
PPDCOMMAND  DefaultBRColorEnhancement={
	"DefaultBREnhanceBlkPrt",
	{
		{  "OFF"	,	"-bp OFF"	},

		{  "ON"	,	"-bp ON"	},
		{ NULL , NULL  }
	}
};

//    ******DefaultBRInputSlot**********
PPDCOMMAND  DefaultBRInputSlot={
	"DefaultBRInputSlot",
	{
		{  "AutoSelect"	,	"-inslot AutoSelect"	},
		{  "Tray1"	,	"-inslot Tray1"	},
		{  "Tray2"	,	"-inslot Tray2"	},
		{  "MPTray"	,	"-inslot MPTray"	},
		{  "Manual"	,	"-inslot Manual"	},
		{ NULL , NULL  }
	}
};

//    ******DefaultBRReversePrint**********
PPDCOMMAND  DefaultBRReverse={
	"DefaultBRReverse",
	{
		{  "OFF"	,	"-rev OFF"	},
		{  "ON"	,	"-rev ON"	},

		{ NULL , NULL  }
	}
};
//    ******DefaultBRJpegPrint**********
/* PPDCOMMAND  DefaultBRJpeg={
	"DefaultBRJpeg",
	{
		{  "Recommended"	,	"-jpeg Recommended"	},
		{  "QualityPrior"	,	"-jpeg QualityPrior"	},
		{  "SpeedPrior"	,	"-jpeg SpeedPrior"	},
		{ NULL , NULL  }
    
	}
};    */

//    ******DefaultBRDuplex**********
PPDCOMMAND DefaultBRDuplex={
	"DefaultBRDuplex",

	{
		{ "None"	,	"-duplex None" },
		{ "DuplexTumble"	,	"-duplex DuplexTumble" },
		{ "DuplexNoTumble"	,	"-duplex DuplexNoTumble" },
		{ NULL	,	NULL }
	}
};     
//    ******DefaultBRManualDuplex**********
/* PPDCOMMAND DefaultManualDuplex={
	"DefaultDuplex",
	{
		{ "off"	,	"-Duplex off" },
		{ "even"	,	"-Duplex even" },
		{ "odd"	,	"-Duplex odd" },
		{ NULL	,	NULL }
	}
};      */

PPDCOMMAND DefaultBRSkipBlank={
	"DefaultBRSkipBlank",
	{
		{ "ON"	,	"-sb ON" },
		{ "OFF"	,	"-sb OFF" },
		{ NULL	,	NULL }
	}
};   


PPDCOMMAND   *ppdcommand_all_list[] = {
	&DefaultBRInputSlot,

	&DefaultBRResolution,
	&DefaultPageSize,
	&DefaultBRMonoColor,
	&DefaultBRGray,
	&DefaultBRMediaType,
//	&DefaultBRColorPaperThick,
//	&DefaultBRBiDir,
//	&DefaultBrMirrorPrint,
//	&DefaultBRDocument,
	&DefaultBRColorMatching,
	&DefaultBRTonerSaveMode,
	&DefaultBRImproveOutput,
	&DefaultBRColorEnhancement,
 // &DefaultBRJpeg,
  &DefaultBRReverse,
  &DefaultBRDuplex,
  &DefaultBRSkipBlank,
//  &DefaultBRManualDuplex,
   NULL
};
/*      PPD Default   end*/
//   +++++++++++++++++++++++++++
//       PPD numerical value

//   +++++++++++++++++++++++++++

CMDLINELIST PPDdefaultN[] = {
	{"DefaultBRBrightness", "-brit "},
	{"DefaultBRContrast", "-cont "},
	{"DefaultBRRed", "-red "},
	{"DefaultBRGreen", "-green "},
	{"DefaultBRBlue", "-blue "},
	{"DefaultBRSaturation", "-satu "},
	{ NULL   ,   NULL    },
};

/*
CMDLINELIST PPDdefaultNValue[] = {
		{"DefaultBRBrightness", "-brit "},
		{"DefaultBRContrast", "-cont "},


		{"DefaultBRRed", "-red "},
		{"DefaultBRGreen", "-green "},

		{"DefaultBRBlue", "-blue "},
		{"DefaultBRSaturation", "-saturation "},
	   { NULL   ,   NULL    },

};


*/





//   +++++++++++++++++++++++++++
//       command line   (Standard command)
//   +++++++++++++++++++++++++++
CMDLINELIST standard_media_commandlinelist[] = {
/*	   {  "A4"   ,   "-pt A4"       },
	   {  "Letter"   ,   "-pt LT"       },
	   {  "Legal"   ,   "-pt LGL"       },
	   {  "Executive"   ,   "-pt EXE"       },



	   {  "A5"   ,   "-pt A5"       },
//	   {  "A6"   ,   "-pt A6"       },
	   {  "B5"   ,   "-pt B5"       },
//	   {  "B6"   ,   "-pt B6"       },
//	   {  "C5"   ,   "-pt C5"       },
//	   {  "EnvC5"   ,   "-pt C5"       },
	   {  "DL"   ,   "-pt DL"       },

	   {  "EnvDL"   ,   "-pt DL"       },
	   {  "Com10"   ,   "-pt COM-10"       },
	   {  "COM10"   ,   "-pt COM-10"       },
	   {  "Com-10"   ,   "-pt COM-10"       },
	   {  "COM-10"   ,   "-pt COM-10"       },
	   {  "EnvCOM10"   ,   "-pt COM-10"       },
	   {  "Env10"   ,   "-pt COM-10"       },
//	   {  "Monarch"   ,   "-pt MONARCH"       },
//	   {  "EnvMonarch"   ,   "-pt MONARCH"       },
	   
	   {  "PlainPaper"   ,   "-md PLAIN"       },

	   {  "ThinPaper"   ,   "-md THIN"       },
	   {  "ThickPaper"   ,   "-md THICK"       },
	   {  "ThickerPaper"   ,   "-md THICKER"       },
//	   {  "BondPaper"   ,   "-md BOND"       },
	   {  "Transparencies"   ,   "-md TRANS"       },
	   {  "Recycled"   ,   "-md RECY"       },
	   
//	   {  "Envelopes"   ,   "-md ENV"       },
//	   {  "Env.Thick"   ,   "-md ENV-THICK"       },
//	   {  "Env.Thin"   ,   "-md ENV-THIN"       },

	   {  "Manual"   ,   "-feed MANUAL"       },
//	   {  "MPTray"   ,   "-feed MP"       },
	   {  "Tray1"   ,   "-feed TRAY1"       },
	   {  "Tray2"   ,   "-feed TRAY2"       },

	   {  "AutoSelect"   ,   "-feed AUTO"       },
*/	   { NULL   ,   NULL    }
};

#endif  //_BRCUPS_COMMANDS_H_
